from django.db import models

# Create your models here.

# product
# name, product price, product description, inventory
class Product(models.Model):
    product_name = models.CharField(max_length=100)
    product_price = models.CharField(max_length=100)
    product_description = models.CharField(max_length=100)
    inventory = models.CharField(max_length=100)

    def __str__(self):
        return self.product_name
