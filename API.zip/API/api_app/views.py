from re import template
from rest_framework import generics, permissions
from rest_framework.response import Response
from knox.models import AuthToken
from .serializers import UserSerializer, RegisterSerializer
from django.contrib.auth import login
from django.shortcuts import render,redirect
from django.http import HttpResponseRedirect
from rest_framework import permissions
from rest_framework.authtoken.serializers import AuthTokenSerializer
from knox.views import LoginView as KnoxLoginView
from django.views.generic.base import TemplateView
from .forms import ProductForm
from .models import Product
from django.urls import reverse

# Register API


class RegisterAPI(generics.GenericAPIView):
    serializer_class = RegisterSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response({
            "user": UserSerializer(user, context=self.get_serializer_context()).data,
            "token": AuthToken.objects.create(user)[1]
        })


class LoginAPI(KnoxLoginView):
    permission_classes = (permissions.AllowAny,)

    def post(self, request, format=None):
        serializer = AuthTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        login(request, user)
        data = super(LoginAPI, self).post(request, format=None)
        # import pdb
        # pdb.set_trace()
        if(data.status_code == 200):
            form = ProductForm()
            stud = Product.objects.all()
            # context = {'user_name': user.get_username(), 'form': form,
            #            'data': stud}
            # return HttpResponseRedirect("/")
            # named_redirect = 
            # return redirect(named_redirect)
            # return reverse('addNshow')
            # return render(request, 'api_app/addnshow.html', context=context)
            if 'admin' in user.get_username():
                user = 'admin'
            elif 'manager' in user.get_username():
                user = 'manager'
            else:
                user='user'
            return HttpResponseRedirect('/')
            # {'user_name': user, 'form': form,'data': stud}
            # import pdb
            # pdb.set_trace()
            # return render(request, 'api_app/addnshow.html', context=context)
            # return render(request, 'api_app/addnshow.html', )
            # return data
            """
            user.get_username()
                get the username and on the basis of user name one can delete or update
            """
            # Send a html file 
        else:
            return data
        


class Home(TemplateView):
    template_name = 'api_app/addnshow.html'
    def post(self, request, *args, **kwargs):
        # import pdb
        # pdb.set_trace()
        form = ProductForm(request.POST)
        if(form.is_valid()):
            print("Data i got : \n")
            product_name = form.cleaned_data['product_name']
            product_price = form.cleaned_data['product_price']
            product_description = form.cleaned_data['product_description']
            inventory = form.cleaned_data['inventory']
            # print("{},{},{}".format(name, email, password))
            form.save()
            # return render(request,'enroll/addNshow.html',{'data':'Check DB!'})
            form = ProductForm()
            stud = Product.objects.all()
            if 'admin' in request.user.get_username():
                role = 'admin'
                class_name=''
            elif 'manager' in request.user.get_username():
                role = 'manager'
                class_name = 'd-none'
            else:
                role='user'
                class_name = 'd-none'
            
            return render(request, 'api_app/addnshow.html', {'form': form, 'data': stud, 'role': role, 'class_name': class_name})

    def get(self, request, *args, **kwargs):
        # import pdb
        # pdb.set_trace()
        if 'admin' in request.user.get_username():
                role = 'admin'
                class_name=''
        elif 'manager' in request.user.get_username():
            role = 'manager'
            class_name = 'd-none'
        else:
            role='user'
            class_name = 'd-none'
            
        form = ProductForm()
        stud = Product.objects.all()
        return render(request, 'api_app/addnshow.html', {'form': form, 'data': stud, 'role': role, 'class_name': class_name})

# To Update details
class Update(TemplateView):

    template_name = 'api_app/update.html'
    def post(self, request, *args, **kwargs):
        
        product = Product.objects.get(pk=kwargs['id'])
        form = ProductForm(request.POST, instance=product)
        if(form.is_valid()):
            form.save()
            return HttpResponseRedirect("/")
        # return render(request, 'api_app/update.html', {'form': form})
    def get(self, request, *args, **kwargs): 
        user = Product.objects.get(pk=kwargs['id'])
        form = ProductForm(instance=user)
        return render(request, 'api_app/update.html', {'form': form})

class Delete(TemplateView):
        template_name = 'api_app/addnshow.html'
        def post(self, request, *args, **kwargs): 
            # import pdb
            # pdb.set_trace() 
            stud = Product.objects.get(pk=kwargs['id'])
            stud.delete()
            print("Data is deleted with id : {}".format(kwargs['id']))
            form = ProductForm()
            stud = Product.objects.all()
            return HttpResponseRedirect("/")


    


        
