from django import forms
from .models import Product


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['product_name','product_price', 'product_description', 'inventory']
        labels = {'product_name': 'Product Name',
                  'product_price': 'Product Price', 'product_description': 'Product Description', 'inventory': 'Inventory'}
        widgets = {
            'product_name': forms.TextInput(attrs={'placeholder': 'Enter product name here', 'class': 'form-control'}),
            'product_price': forms.TextInput(attrs={'placeholder': 'Enter product price here', 'class': 'form-control'}),
            'product_description': forms.TextInput(attrs={'placeholder': 'Enter product description here', 'class': 'form-control'}),
            'inventory': forms.TextInput(attrs={'placeholder': 'Enter inventory here', 'class': 'form-control'})
            # 'password': forms.PasswordInput(render_value=True, attrs={'placeholder': 'Enter password here', 'class': 'form-control'}),

        }
